<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
include 'db_connect.php';

$sql = "SELECT product, price, stock_quantity, PI() AS pi_value FROM table_numfunc";
$result = mysqli_query($conn, $sql);

echo "<h2>PI() Function Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>product</th><th>price</th><th>stock_quantity</th><th>PI()</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['product']) . "</td>";
    echo "<td>" . htmlspecialchars($row['price']) . "</td>";
    echo "<td>" . htmlspecialchars($row['stock_quantity']) . "</td>";
    echo "<td>" . htmlspecialchars(round($row['pi_value'], 4)) . "</td>";
    echo "</tr>";
}

echo "</table>";
mysqli_close($conn);
?>

</body>
</html>