<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php 
include 'db_connect.php'; 
$sql = "SELECT id, product_name, BIN(id) AS bin_value FROM table_advfunc";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
echo "<h2>BIN() Function Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>id</th><th>product_name</th><th>BIN(id)</th></tr>";
while ($row = mysqli_fetch_assoc($result)) {
    $id = $row['id'];
    $someColumn = trim($row['product_name']);
    $binValue = $row['bin_value'];

    echo "<tr>";
    echo "<td>" . htmlspecialchars($id) . "</td>";
    echo "<td>" . htmlspecialchars($someColumn) . "</td>";
    echo "<td>" . htmlspecialchars($binValue) . "</td>";
    echo "</tr>";
}
?>

</html>