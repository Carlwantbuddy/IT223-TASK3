<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php
include 'db_connect.php';

$sql = "SELECT CURDATE() AS result";
$result = $conn->query($sql);

echo "<h1>CURDATE() FUNCTION EXAMPLE</h1>";

echo "<table border='1'><tr><th>Current Date</th></tr>";

$row = $result->fetch_assoc();
echo "<tr><td>{$row['result']}</td></tr>";

echo "</table>";

$conn->close();
?>

</html>