<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

//removes spaces
$sql = "SELECT padded_text, TRIM(padded_text) AS result FROM table1";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>TRIM() Function Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Original Text</th><th>Trimmed Text</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['padded_text']) . "</td>";
    echo "<td>" . htmlspecialchars($row['result']) . "</td>";
    echo "</tr>";
}
echo "</table>";

mysqli_close($conn);

?>
</html>