<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php
include 'db_connect.php';

$result = $conn->query("SELECT LAST_INSERT_ID() AS result");

echo "<h1>LAST_INSERT_ID()</h1>";
echo "<table border='1'><tr><th>Last Insert ID</th></tr>";

$row = $result->fetch_assoc();
echo "<tr><td>{$row['result']}</td></tr>";

echo "</table>";
$conn->close();
?>
</html>