<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

$sql = "SELECT sentence, LENGTH(sentence) AS result FROM table1";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>LENGTH() Function Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Sentence</th><th>Length</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $sentence = trim($row['sentence']);
    echo "<tr>";
    echo "<td>" . htmlspecialchars($sentence) . "</td>";
    echo "<td>" . $row['result'] . "</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);
?>
</html>