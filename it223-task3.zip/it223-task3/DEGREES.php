<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
include 'db_connect.php';

$sql = "SELECT product, price, stock_quantity, DEGREES(price) AS degrees_price FROM table_numfunc";
$result = mysqli_query($conn, $sql);

if (!$result) { die("Query failed: " . mysqli_error($conn)); }

echo "<h2>DEGREES() Function Example</h2>";
echo "<p>DEGREES() converts radians to degrees.</p>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>product</th><th>price (radians)</th><th>stock_quantity</th><th>DEGREES(price)</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars(trim($row['product'])) . "</td>";
    echo "<td>" . htmlspecialchars($row['price']) . "</td>";
    echo "<td>" . htmlspecialchars($row['stock_quantity']) . "</td>";
    echo "<td>" . htmlspecialchars(round($row['degrees_price'], 2)) . "</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);
?>

</body>
</html>