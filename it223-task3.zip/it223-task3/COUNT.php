<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
include 'db_connect.php';

$sql = "SELECT COUNT(*) AS total_products FROM table_numfunc";
$result = mysqli_query($conn, $sql);

if (!$result) { die("Query failed: " . mysqli_error($conn)); }

$row = mysqli_fetch_assoc($result);
$total = $row['total_products'];

echo "<h2>COUNT() Function Example</h2>";
echo "<p>COUNT() returns the number of rows in the table.</p>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Total Products</th></tr>";
echo "<tr><td>" . htmlspecialchars($total) . "</td></tr>";
echo "</table>";

mysqli_close($conn);
?>

</body>
</html>