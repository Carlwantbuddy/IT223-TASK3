<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>

<?php 
include 'db_connect.php'; 

$sql = "SELECT CONNECTION_ID() AS connection_id";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

$row = mysqli_fetch_assoc($result);
$connectionID = $row['connection_id'];

echo "<h2>CONNECTION_ID() Function Example</h2>";
echo "<p>Your current database connection ID is: <strong>$connectionID</strong></p>";

mysqli_close($conn);

?>
</html>