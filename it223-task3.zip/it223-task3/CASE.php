<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>

<?php 
include 'db_connect.php'; 

$sql = "SELECT 
            product_name, 
            BIN(CHAR_LENGTH(product_name)) AS binary_value,
            CASE 
                WHEN CHAR_LENGTH(product_name) <= 6 THEN 'Short'
                WHEN CHAR_LENGTH(product_name) <= 12 THEN 'Medium'
                ELSE 'Long'
            END AS name_category
        FROM table_advfunc";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>BIN() + CASE Function Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Product Name</th><th>Binary Length</th><th>Characters</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $productName = trim($row['product_name']);
    $binaryValue = $row['binary_value'];
    $category = $row['name_category'];

    echo "<tr>";
    echo "<td>" . htmlspecialchars($productName) . "</td>";
    echo "<td>" . htmlspecialchars($binaryValue) . "</td>";
    echo "<td>" . htmlspecialchars($category) . "</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);


?>
</html>