<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

// Comparing first_name and last_name
$sql = "SELECT id, first_name, last_name, STRCMP(first_name, last_name) AS comparison_result FROM table1";
$result = $conn->query($sql);

echo "<h1>STRCMP() Function Example</h1>";
echo "<p>Compares First Name and Last Name alphabetically.</p>";
echo "<ul>
        <li><strong>0</strong>: Strings are identical</li>
        <li><strong>-1</strong>: First Name comes BEFORE Last Name alphabetically</li>
        <li><strong>1</strong>: First Name comes AFTER Last Name alphabetically</li>
      </ul>";

if ($result->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Comparison Result</th>
            </tr>";
    // 3. Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["id"]. "</td>
                <td>" . $row["first_name"]. "</td>
                <td>" . $row["last_name"]. "</td>
                <td>" . $row["comparison_result"]. "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();

?>
</html>