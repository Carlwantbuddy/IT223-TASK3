<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

//Using LPAD to fill names to 15 characters
$sql = "SELECT id, first_name, LPAD(first_name, 15, '.') AS padded_name FROM table1";
$result = $conn->query($sql);

echo "<h1>LPAD() Function Result</h1>";
echo "<p>Adds dots to the left of the name until the total length is 15.</p>";

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>ID</th><th>Original</th><th>Result</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id"]. "</td><td>" . $row["first_name"]. "</td><td><code>" . $row["padded_name"]. "</code></td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();


?>
</html>