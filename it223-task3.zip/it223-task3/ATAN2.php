<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    include 'db_connect.php';

    $sql = "
        SELECT 
            product, 
            stock_quantity, 
            price, 
            ATAN2(stock_quantity, price) AS atan2_value
        FROM table_numfunc
    ";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    echo "<h2>ATAN2() Function Example (Numeric Function)</h2>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Product</th><th>Stock Quantity</th><th>Price</th><th>ATAN2(stock_quantity, price)</th></tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        $product = trim($row['product']);
        $stockQuantity = $row['stock_quantity'];
        $price = $row['price'];
        $atan2Value = $row['atan2_value'];

        echo "<tr>";
        echo "<td>" . htmlspecialchars($product) . "</td>";
        echo "<td>" . htmlspecialchars($stockQuantity) . "</td>";
        echo "<td>" . htmlspecialchars($price) . "</td>";
        echo "<td>" . htmlspecialchars(round($atan2Value, 4)) . "</td>";
        echo "</tr>";
    }

    mysqli_close($conn);
    ?>

</body>
</html>