<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

// Using INSTR to find a word's location
$sql = "SELECT id, sentence, INSTR(sentence, 'are') AS word_pos FROM table1";
$result = $conn->query($sql);

echo "<h1>INSTR() Function Result</h1>";

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>ID</th><th>Sentence</th><th>'are' starts at</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id"]. "</td><td>" . $row["sentence"]. "</td><td>" . $row["word_pos"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();

?>
</html>