<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php
include 'db_connect.php';

$sql = "SELECT LOCALTIMESTAMP() AS result";
$result = $conn->query($sql);

echo "<h1>LOCALTIMESTAMP()</h1>";
echo "<table border='1'><tr><th>Local Timestamp</th></tr>";

$row = $result->fetch_assoc();
echo "<tr><td>{$row['result']}</td></tr>";

echo "</table>";
$conn->close();
?>

</html>