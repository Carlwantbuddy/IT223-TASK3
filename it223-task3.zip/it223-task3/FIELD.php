<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

// Using FIELD to find position of first_name
$sql = "SELECT id, first_name, FIELD(first_name, 'Alex', 'Carl', 'Elyza') AS name_index FROM table1";
$result = $conn->query($sql);

echo "<h1>FIELD() Function Example</h1>";

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>ID</th><th>First Name</th><th>Position Index</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id"]. "</td><td>" . $row["first_name"]. "</td><td>" . $row["name_index"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();

?>
</html>