<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

//Using SUBSTRING_INDEX to get the first two items
$sql = "SELECT id, csv_values, SUBSTRING_INDEX(csv_values, ',', 2) AS first_two FROM table1";
$result = $conn->query($sql);

echo "<h1>SUBSTRING_INDEX() Function Example</h1>";
echo"<h3>Using SUBSTRING_INDEX to get the first two items</h3>";

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>ID</th><th>Original CSV</th><th>First Two Items</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id"]. "</td><td>" . $row["csv_values"]. "</td><td>" . $row["first_two"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();

?>
</html>