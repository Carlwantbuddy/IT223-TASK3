<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
include 'db_connect.php';

$sql = "
    SELECT 
        product, 
        stock_quantity, 
        (stock_quantity / (SELECT MAX(stock_quantity) FROM table_numfunc)) AS normalized_stock,
        ASIN(stock_quantity / (SELECT MAX(stock_quantity) FROM table_numfunc)) AS asin_value
    FROM table_numfunc
";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>ASIN() Function Example (Numeric Function)</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Product</th><th>Stock Quantity</th><th>Normalized Stock</th><th>ASIN(normalized_stock)</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $product = trim($row['product']);
    $stockQuantity = $row['stock_quantity'];
    $normalizedStock = $row['normalized_stock'];
    $asinValue = $row['asin_value'];

    echo "<tr>";
    echo "<td>" . htmlspecialchars($product) . "</td>";
    echo "<td>" . htmlspecialchars($stockQuantity) . "</td>";
    echo "<td>" . htmlspecialchars(round($normalizedStock, 2)) . "</td>";
    echo "<td>" . htmlspecialchars(round($asinValue, 4)) . "</td>";
    echo "</tr>";
}

mysqli_close($conn);
?>

</body>
</html>