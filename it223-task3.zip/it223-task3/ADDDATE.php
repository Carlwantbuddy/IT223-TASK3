<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php
include 'db_connect.php'; 

    
$sql = "SELECT order_date, ADDDATE(order_date, INTERVAL 7 DAY) AS result FROM table2";
$result = $conn->query($sql);

echo "<h1>ADDDATE() FUNCTION EXAMPLE</h1>";

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>Order Date</th><th>Date + 7 Days</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>{$row['order_date']}</td><td>{$row['result']}</td></tr>";
    }

    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>



</html>