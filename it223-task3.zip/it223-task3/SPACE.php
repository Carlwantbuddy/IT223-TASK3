<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

$sql = "SELECT id, CONCAT(first_name, SPACE(10), last_name) AS wide_name FROM table1";
$result = $conn->query($sql);

echo "<h1>SPACE() Function Result</h1>";
echo "<p>Concatenates first and last name with 10 blank spaces in between.</p>";

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>ID</th><th>Result</th></tr>";
    while($row = $result->fetch_assoc()) {
        // We use <pre> so the browser actually shows the multiple spaces
        echo "<tr><td>" . $row["id"]. "</td><td><pre>" . $row["wide_name"]. "</pre></td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();

?>
</html>