<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>

<?php
include 'db_connect.php';

$sql = "SELECT product_name, IF(stock_quantity > 0, 'In Stock', 'Out of Stock') AS result FROM table_advfunc";
$result = $conn->query($sql);

echo "<h1>IF()</h1>";
echo "<table border='1'><tr><th>Product</th><th>Status</th></tr>";

while($row = $result->fetch_assoc()){
    echo "<tr><td>{$row['product_name']}</td><td>{$row['result']}</td></tr>";
}

echo "</table>";
$conn->close();
?>

</html>