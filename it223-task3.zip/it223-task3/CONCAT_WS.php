<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

// SQL query: concatenate first_name, last_name, and code with a dash
$sql = "SELECT first_name, last_name, code, CONCAT_WS('-', TRIM(first_name), TRIM(last_name), code) AS concatenated_ws FROM table1";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>CONCAT_WS() Function Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>First Name</th><th>Last Name</th><th>Code</th><th>Concatenated with Dash</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $firstName = trim($row['first_name']);
    $lastName = trim($row['last_name']);
    echo "<tr>";
    echo "<td>" . htmlspecialchars($firstName) . "</td>";
    echo "<td>" . htmlspecialchars($lastName) . "</td>";
    echo "<td>" . htmlspecialchars($row['code']) . "</td>";
    echo "<td>" . htmlspecialchars($row['concatenated_ws']) . "</td>";
    echo "</tr>";
}
echo "</table>";

mysqli_close($conn);
?>
</html>