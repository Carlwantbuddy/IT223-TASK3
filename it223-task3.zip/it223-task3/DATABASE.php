<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>

<?php
include 'db_connect.php'; 

$sql = "SELECT 
            product_name,
            price,
            DATABASE() AS current_database
        FROM table_advfunc";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>DATABASE() Function Advanced Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Product Name</th><th>Price</th><th>Database Name</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $productName = htmlspecialchars(trim($row['product_name']));
    $price = htmlspecialchars($row['price']);
    $databaseName = htmlspecialchars($row['current_database']);

    echo "<tr>";
    echo "<td>$productName</td>";
    echo "<td>$price</td>";
    echo "<td>$databaseName</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);
?>

</html>