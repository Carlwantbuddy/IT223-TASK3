<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
include 'db_connect.php';

$sql = "SELECT product, price, stock_quantity, POW(price, 2) AS pow_price FROM table_numfunc";
$result = mysqli_query($conn, $sql);

echo "<h2>POW() Function Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>product</th><th>price</th><th>stock_quantity</th><th>POW(price, 2)</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $powValue = $row['pow_price'];
    if ($powValue > 1e10) $powValue = "too large";
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['product']) . "</td>";
    echo "<td>" . htmlspecialchars($row['price']) . "</td>";
    echo "<td>" . htmlspecialchars($row['stock_quantity']) . "</td>";
    echo "<td>" . htmlspecialchars(is_numeric($powValue) ? round($powValue, 4) : $powValue) . "</td>";
    echo "</tr>";
}

echo "</table>";
mysqli_close($conn);
?>

</body>
</html>