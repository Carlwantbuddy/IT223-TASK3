<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

// concatenate first_name and last_name
$sql = "SELECT first_name, last_name, CONCAT(TRIM(first_name), ' ', TRIM(last_name)) AS full_name_concat FROM table1";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
echo "<h2>CONCAT() Function Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>First Name</th><th>Last Name</th><th>Concatenated Full Name</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $firstName = trim($row['first_name']);
    $lastName = trim($row['last_name']);
    echo "<tr>";
    echo "<td>" . htmlspecialchars($firstName) . "</td>";
    echo "<td>" . htmlspecialchars($lastName) . "</td>";
    echo "<td>" . htmlspecialchars($row['full_name_concat']) . "</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);
?>
</html>