<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

// Using RIGHT to get the First 5 characters
$sql = "SELECT id, code, LEFT(code, 5) AS code_suffix FROM table1";
$result = $conn->query($sql);

echo "<h1>LEFT() Function Result</h1>";
echo "<p>Getting the First 5 characters from the 'code' column.</p>";

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>ID</th><th>Full Code</th><th>First 5 Chars</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id"]. "</td><td>" . $row["code"]. "</td><td>" . $row["code_suffix"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();

?>
</html>