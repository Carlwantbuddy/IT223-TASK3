<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>

<?php
include 'db_connect.php'; 

$sql = "SELECT 
            product_name,
            price,
            CONVERT(price, CHAR) AS price_as_text,
            CONCAT('Price: $', CONVERT(price, CHAR)) AS display_price
        FROM table_advfunc";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>Advanced CONVERT() Function Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Product Name</th><th>Original Price</th><th>Converted Price (Text)</th><th>Display Price</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $productName = htmlspecialchars(trim($row['product_name']));
    $price = htmlspecialchars($row['price']);
    $priceText = htmlspecialchars($row['price_as_text']);
    $displayPrice = htmlspecialchars($row['display_price']);

    echo "<tr>";
    echo "<td>$productName</td>";
    echo "<td>$price</td>";
    echo "<td>$priceText</td>";
    echo "<td>$displayPrice</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);
?>


</html>