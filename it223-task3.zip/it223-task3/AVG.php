<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    include 'db_connect.php';

    $sql = "SELECT AVG(price) AS avg_price FROM table_numfunc";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    $row = mysqli_fetch_assoc($result);
    $avgPrice = $row['avg_price'];

    echo "<h2>AVG() Function Example (Numeric Function)</h2>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Average Price</th></tr>";
    echo "<tr><td>" . htmlspecialchars(round($avgPrice, 2)) . "</td></tr>";
    echo "</table>";

    mysqli_close($conn);
    ?>

</body>
</html>