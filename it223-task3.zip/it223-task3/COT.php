<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
include 'db_connect.php';

$sql = "
    SELECT 
        product, 
        price, 
        stock_quantity, 
        1 / TAN(price) AS cot_price
    FROM table_numfunc
";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>COT() Function Example</h2>";
echo "<p>COT() is calculated as 1 / TAN(value in radians).</p>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>product</th><th>price</th><th>stock_quantity</th><th>COT(price)</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars(trim($row['product'])) . "</td>";
    echo "<td>" . htmlspecialchars($row['price']) . "</td>";
    echo "<td>" . htmlspecialchars($row['stock_quantity']) . "</td>";
    $cotValue = $row['cot_price'];
    
    if (abs($cotValue) > 1e10) $cotValue = "undefined";
    echo "<td>" . htmlspecialchars(is_numeric($cotValue) ? round($cotValue, 4) : $cotValue) . "</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);
?>

</body>
</html>