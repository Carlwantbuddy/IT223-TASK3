<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<?php 
include 'db_connect.php'; 

$sql = "SELECT mixed_case, UCASE(mixed_case) AS result FROM table1";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>UCASE() Function Example</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Original Text</th><th>Uppercase</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['mixed_case']) . "</td>";
    echo "<td>" . htmlspecialchars($row['result']) . "</td>";
    echo "</tr>";
}
echo "</table>";

mysqli_close($conn);

?>
</html>