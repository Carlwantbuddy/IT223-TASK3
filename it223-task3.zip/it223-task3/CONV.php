<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>

<?php 
include 'db_connect.php'; 

$sql = "SELECT 
            product_name, 
            CHAR_LENGTH(product_name) AS name_length,
            CONV(CHAR_LENGTH(product_name), 10, 2) AS length_in_binary
        FROM table_advfunc";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>CONV() Function Example (Name Length → Binary)</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Product Name</th><th>Name Length (Decimal)</th><th>Name Length (Binary)</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $productName = htmlspecialchars(trim($row['product_name']));
    $nameLength = htmlspecialchars($row['name_length']);
    $binaryLength = htmlspecialchars($row['length_in_binary']);

    echo "<tr>";
    echo "<td>$productName</td>";
    echo "<td>$nameLength</td>";
    echo "<td>$binaryLength</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);



?>
</html>