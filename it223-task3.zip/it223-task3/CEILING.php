<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
include 'db_connect.php';

$sql = "SELECT product, price, stock_quantity, CEILING(price) AS ceiling_price, CEILING(stock_quantity) AS ceiling_stock FROM table_numfunc";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "<h2>CEILING() Function Example</h2>";
echo "<p>CEILING() returns the smallest integer greater than or equal to the value.</p>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>product</th><th>price</th><th>stock_quantity</th><th>CEILING(price)</th><th>CEILING(stock_quantity)</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars(trim($row['product'])) . "</td>";
    echo "<td>" . htmlspecialchars($row['price']) . "</td>";
    echo "<td>" . htmlspecialchars($row['stock_quantity']) . "</td>";
    echo "<td>" . htmlspecialchars($row['ceiling_price']) . "</td>";
    echo "<td>" . htmlspecialchars($row['ceiling_stock']) . "</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);
?>

</body>
</html>